<template>
	<view>
		<text class="text">空空滴，还没有记录</text>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {

		}
	}
</script>

<style lang="scss">
	.text {
		position: relative;
		display: block;
		left: 240rpx;
		margin: 200rpx auto;
		font-size: 30rpx;
		color: #C0C0C0;
	}
</style>
